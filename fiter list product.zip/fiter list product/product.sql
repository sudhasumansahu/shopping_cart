-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2020 at 03:44 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `ram` varchar(10) NOT NULL,
  `hdd` varchar(10) NOT NULL,
  `processor` varchar(100) NOT NULL,
  `screen_size` varchar(100) NOT NULL,
  `os` varchar(100) NOT NULL,
  `Product_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `brand`, `product_name`, `product_price`, `ram`, `hdd`, `processor`, `screen_size`, `os`, `Product_image`) VALUES
(1, 'Acer', 'Acer Predetor', '120000', '16GB', '1TB', 'core i7', '15.6 inch', 'windows 10', 'images/acer1.jpg'),
(2, 'Acer', 'Acer Laptop', '60000', '8GB', '500GB', 'core i3', '14 inch', 'DOS', 'images/acer2.jpg'),
(3, 'Asus', 'ASUS Laptop', '75000', '8GB', '1TB', 'core i5', '15.6 inch', 'windows 10', 'images/asus1.jpg'),
(4, 'Dell', 'Dell Inspiron', '42000', '4GB', '500GB', 'core i3', '15.6 inch', 'DOS', 'images/dell1.jpg'),
(5, 'Dell ', 'Dell Laptop', '32000', '6GB', '1TB', 'Core i3 ', '15.6 inch', 'windows 10', 'images/dell2.jpg'),
(6, 'Dell', 'Dell XPS 15', '30000', '4GB', '500GB', 'core i5', '14 inch', 'ubuntu', 'images/dell3.jpg'),
(7, 'HP', 'HP Pavillion Laptop', '40000', '4GB', '1TB', 'core i3', '15.6 inch', 'DOS', 'images/hp1.jpg'),
(8, 'HP', 'HP Envy', '50000', '8GB', '1TB', 'core i5', '15.6 inch', 'windows 8.1', 'images/hp2.jpg'),
(9, 'HP', 'HP Laptop', '38000', '8GB', '2TB', 'core i5', '15.6 inch', 'windows 10', 'images/hp3.jpg'),
(10, 'Lenovo', 'Lenovo Laptop', '34000', '6GB', '1TB', 'core i3', '14 inch', 'ubuntu', 'images/lenovo1.jpg'),
(11, 'Lenovo', 'Lenovo Laptop', '45000', '16GB', '1TB', 'core i7', '14 inch', 'windows 8.1', 'images/lenovo2.png'),
(12, 'MSI', 'MSI Gaming Laptop', '85000', '16GB', '2TB', 'core i7', '15.6 inch', 'windows 10', 'images/msi1.jpg'),
(13, 'Toshiba', 'Toshiba Laptop', '25000', '2GB', '500GB', 'core i3', '15.6 inch', 'DOS', 'images/toshiba1.jpg'),
(14, 'Apple', 'Apple Mac Book Pro', '150000', '8GB', '1TB', 'core i5', '14 inch', 'Mac OS', 'images/apple1.jpg'),
(15, 'Apple', 'Apple MAC Book Pro', '250000', '16GB', '2TB', 'core i5', '15.6 inch', 'Mac OS', 'images/apple2.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
