<?php
require 'config.php';
?>

<!DOCTYPE html>
<html>
<head>
	<!--meta tags-->
	<meta charset="utf-8">
	<meta name="author" content="sudhasuman">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!--cdn links--->
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!--cdn links-->
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

  <title>Product Filter</title>
</head>
<body>
<h3 class="text-center text-light bg-danger">Shopping cart</h3>

<div class="container-fluid">
	<div class="row">
		<div class="col-lg-3">
			<h5>Filter Product</h5>
			<hr>

			<h6 class="text-danger">Select Brand</h6>
			<ul class="list-group">
				<?php
				$sql="SELECT DISTINCT brand FROM product ORDER BY brand";
				$result=$conn->query($sql);
				while ($row=$result->fetch_assoc()) {
				 ?>
				 <li class="list-group-item">
				 	<div class="form-check">
				 		<label class="form-check-label">

				 			<input type="checkbox" class="form-check-input product_check" value="<?=$row['brand'];?>" id="brand">
				 			<?=$row['brand']; ?>
				 			
				 		</label>
				 		
				 	</div>
				 	
				 </li>
				<?php } ?>
			</ul>

			<h6 class="text-danger">Select RAM</h6>
			<ul class="list-group">
				<?php
				$sql="SELECT DISTINCT ram FROM product ORDER BY ram";
				$result=$conn->query($sql);
				while ($row=$result->fetch_assoc()) {
				 ?>
				 <li class="list-group-item">
				 	<div class="form-check">
				 		<label class="form-check-label">

				 			<input type="checkbox" class="form-check-input product_check" value="<?=$row['ram'];?>" id="ram">
				 			<?=$row['ram']; ?>
				 			
				 		</label>
				 		
				 	</div>
				 	
				 </li>
				<?php } ?>
			</ul>

			<h6 class="text-danger">Select HDD</h6>
			<ul class="list-group">
				<?php
				$sql="SELECT DISTINCT hdd FROM product ORDER BY hdd";
				$result=$conn->query($sql);
				while ($row=$result->fetch_assoc()) {
				 ?>
				 <li class="list-group-item">
				 	<div class="form-check">
				 		<label class="form-check-label">

				 			<input type="checkbox" class="form-check-input product_check" value="<?=$row['hdd'];?>" id="hdd">
				 			<?=$row['hdd']; ?>
				 			
				 		</label>
				 		
				 	</div>
				 	
				 </li>
				<?php } ?>
			</ul>

			<h6 class="text-danger">Select Processor</h6>
			<ul class="list-group">
				<?php
				$sql="SELECT DISTINCT processor FROM product ORDER BY processor";
				$result=$conn->query($sql);
				while ($row=$result->fetch_assoc()) {
				 ?>
				 <li class="list-group-item">
				 	<div class="form-check">
				 		<label class="form-check-label">

				 			<input type="checkbox" class="form-check-input product_check" value="<?=$row['processor'];?>" id="processor">
				 			<?=$row['processor']; ?>
				 			
				 		</label>
				 		
				 	</div>
				 	
				 </li>
				<?php } ?>
			</ul>

			<h6 class="text-danger">Select Screen Size</h6>
			<ul class="list-group">
				<?php
				$sql="SELECT DISTINCT screen_size FROM product ORDER BY screen_size";
				$result=$conn->query($sql);
				while ($row=$result->fetch_assoc()) {
				 ?>
				 <li class="list-group-item">
				 	<div class="form-check">
				 		<label class="form-check-label">

				 			<input type="checkbox" class="form-check-input product_check" value="<?=$row['screen_size'];?>" id="screensize">
				 			<?=$row['screen_size']; ?>
				 			
				 		</label>
				 		
				 	</div>
				 	
				 </li>
				<?php } ?>
			</ul>


			<h6 class="text-danger">Select OS</h6>
			<ul class="list-group">
				<?php
				$sql="SELECT DISTINCT os FROM product ORDER BY os";
				$result=$conn->query($sql);
				while ($row=$result->fetch_assoc()) {
				 ?>
				 <li class="list-group-item">
				 	<div class="form-check">
				 		<label class="form-check-label">

				 			<input type="checkbox" class="form-check-input product_check" value="<?=$row['os'];?>" id="os">
				 			<?=$row['os']; ?>
				 			
				 		</label>
				 		
				 	</div>
				 	
				 </li>
				<?php } ?>
			</ul>


		</div>


		<div class="col-lg-9">
			<h5 class="text-center" id="textChange">All Products</h5>
			<hr>	
			<div class="text-center">
				<img src="images/load.gif" id="loader" width="170" style="display: none;">
				
			</div>

			<div class="row" id="result">
				<?php
				$sql="SELECT * FROM product";
				$result=$conn->query($sql);
				while ($row=$result->fetch_assoc()) {
					
				?>

				<div class="col-md-3 mb-2">
					<div class="card-deck">
						<div class="card border-secondary">
							<img  class="card-img-top" src="<?= $row['Product_image']; ?>">
							<div class="card-img-overlay">
								<h6 style="margin-top: 175px;" class="text-light bg-danger text-center rounded p-1"><?=$row['product_name']; ?></h6>
								
							</div>
									<div class="card-body">
										<h4 class="card-title text-danger">Price:<?=number_format($row['product_price']); ?>/-</h4>
										<p>
											RAM: <?=$row['ram']; ?><br>
											HDD: <?=$row['hdd']; ?><br>
											Processor: <?=$row['processor']; ?><br>
											Screen Size: <?=$row['screen_size']; ?><br>
											OS: <?=$row['os']; ?><br>
										</p>

										<a href="#" class="btn btn-info btn-block">Add to Cart</a>
									</div>

						</div>
						
					</div>
					
				</div>
			<?php } ?>
				
			</div>

		</div>
		
	</div>
	
</div>


</body>
</html>