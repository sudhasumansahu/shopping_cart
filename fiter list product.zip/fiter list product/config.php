<?php

$conn=new mysqli("localhost","root","","shopping");
if ($conn->connect_error) {
	die("connection Failed !".$conn->connect_error);
	
	
}


?>